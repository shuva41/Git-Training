var button = document.getElementById('theButton');

//add event listener
button.addEventListener('click', function(event) {
  alort("You are awesome!");
});